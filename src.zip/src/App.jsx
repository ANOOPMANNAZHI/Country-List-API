import React, { useState, useEffect } from 'react';
import './App.css'
function App() {
  const [countries, setCountries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("https://restcountries.com/v3.1/all")
      .then(response => response.json())
      .then(data => {
        setCountries(data);
        setLoading(false);
      })
      .catch(error => {
        console.log("Error fetching countries data: ", error);
        setLoading(false);
      });
  }, []);

  return (
    <div className="App">
      <h1>Country Information</h1>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div className="countries-list">
          <ul>
          {Array.isArray(countries) && countries.map(country => (
            <li>
            <div key={country.cca3} className="country">
              <h2>{country.name.common}</h2>
              <img  src={country.flags.png} alt={country.name.common} />
            </div>
            </li>
          ))}

          </ul>
          
        </div>
      )}
    </div>
  );
}

export default App;
